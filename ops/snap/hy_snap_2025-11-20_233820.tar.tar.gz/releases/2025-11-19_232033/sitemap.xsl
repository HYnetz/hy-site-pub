<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:template match="/"><html><body><h1>Sitemap Index</h1>
<ul><xsl:for-each select="//sitemap/loc"><li><a href="{.}"><xsl:value-of select="."/></a></li></xsl:for-each></ul>
</body></html></xsl:template></xsl:stylesheet>
